/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**","./src/components/*",".src/pages/*"],
  theme: {
    extend: {},
  },
  plugins: [],
}
